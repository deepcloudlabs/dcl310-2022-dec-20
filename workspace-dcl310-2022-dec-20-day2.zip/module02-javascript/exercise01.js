// 1. Functional Programming
// 2. Asynchronous Programming
// 3. Event-Driven Programming
// 4. Object-Based
// 5. Object-Oriented Programming
// var, let, const
// global
// window
var x = 42;
window.setInterval()