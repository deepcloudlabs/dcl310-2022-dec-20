class A {
    #lastname = "bauer";
    constructor() {
        this.firstname = "jack";
    }
}