$(document).ready(()=>{
   $("#movies tbody a[href]").attr("target","_blank");
});