jQuery(document).ready(function(){
   alert("Hello Mars");
});
jQuery(document).ready(function(){
    alert("Hello Moon");
});
jQuery(document).ready(function(){
    alert("Hello Sun");
});